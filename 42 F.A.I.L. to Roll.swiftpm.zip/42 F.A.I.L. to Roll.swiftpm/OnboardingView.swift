//
//  OnboardingView.swift
//  42 F.A.I.L. to Roll
//
//  Created by Antonia Angelia Widjaja on 24/02/24.
//

import SwiftUI
import SpriteKit

struct OnboardingView: View {
    
    var body: some View {
        NavigationView{
            ZStack{
                Image("BG")
                    .resizable()
                    .aspectRatio(contentMode: .fill)
                    .edgesIgnoringSafeArea(.all)
                
                VStack{
                    Spacer()
                    Text("42 F.A.I.L. to ROLL")
                        .foregroundColor(.white)
                        .font(.largeTitle)
                        .monospaced()
                        .bold()
                        .padding()
                    
                    NavigationLink(destination: SwiftUIView()) {
                        Text("START")
                            .foregroundColor(.green)
                            .font(.title)
                            .bold()
                            .padding()
                        
                    }
                    Spacer()
                    Spacer()
                    Spacer()
                    NavigationLink(destination: ContentView()) {
                        Text("Background Story")
                            .foregroundColor(.gray)
                            .font(.title)
                            .padding()
                    }
                    Spacer()
                }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}
