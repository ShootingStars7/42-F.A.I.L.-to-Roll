import SwiftUI

struct ContentView: View {
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 20) {
                Text("Who’s not afraid of FAILing?")
                    .font(.title)
                    .monospaced()
                
                Text("As a former student mentor, teacher, and a learner myself, I understand how tough it is to kick start something new when you're haunted by the fear of failing. But what if we switch FAIL as F.A.I.L. (First Attempt In Learning)? There’s always a first time for everything, which might lead to a success in the future, whether it is to reach our end goal, or just to be the best version of ourselves.")
                    .font(.title2)
                
                Text("This journey in learning inspired me to create 42 F.A.I.L. to ROLL, where we’ll be helping Glee the Triangle in his journey of learning how to roll. I use basic shapes in representing the journey and basic gestures to make it easier to understand for everyone of all ages.")
                    .font(.title2)
                
                Text("In his journey, Glee tries a bunch of ways with the swipe gestures to roll. Sure, he fails a few times at first, but he learns bits and pieces along the way that helps him keep rolling until he nails it.")
                    .font(.title2)
                
                Text("Just like Glee, I hope we’ll gleefully take that first try in learning until we get to reach our end goal.")
                    .font(.title2)
                
                Text("Keep rolling, happy learning!")
                    .font(.title2)
            }
            .padding()
        }
        .frame(width: 600)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

