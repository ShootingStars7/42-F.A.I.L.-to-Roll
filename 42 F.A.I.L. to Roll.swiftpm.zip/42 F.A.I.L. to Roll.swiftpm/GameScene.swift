//
//  GameScene.swift
//  42 F.A.I.L. to Roll
//
//  Created by Antonia Angelia Widjaja on 24/02/24.
//

import Foundation
import SpriteKit

class GameScene: SKScene {
    
    // Story Phase
    enum StoryPhase: Int{
        case phase0
        case phase1
        case phase2
        case phase3
        case phase4
        case phase5
        case phase6
        case phase7
        case phase8
        case phase9
        case phase10
        case phase11
        case phase12
        case phase13
        case phase14
    }
    
    var shouldGoToNextPhase: Bool = false
    var currentPhase: StoryPhase = .phase1
    
    // MARK: - List of Objects
    var isPhase1Complete = false
    
    let myFirstNode = SKNode()
    let line = SKSpriteNode(imageNamed: "Line")
    let greenFlag = SKSpriteNode(imageNamed: "GreenFlag")
    let cameraNode = SKCameraNode()
    
    let glee = SKSpriteNode(imageNamed:"Glee")
    let gleeO = SKSpriteNode(imageNamed:"GleeO")
    let gleeSad = SKSpriteNode(imageNamed: "GleeSad")
    
    let square = SKSpriteNode(imageNamed: "Square")
    let squareHappy = SKSpriteNode(imageNamed: "SquareHappy")
    let squareSad = SKSpriteNode(imageNamed: "SquareSad")
    
    let circle = SKSpriteNode(imageNamed: "Below")
    let circleSmile = SKSpriteNode(imageNamed: "CircleSmile")
    let circleHappy = SKSpriteNode(imageNamed: "CircleHappy")
    let circleO = SKSpriteNode(imageNamed: "CircleO")
    let circleSad = SKSpriteNode(imageNamed: "CircleSad")
    
    let gleeChange = SKSpriteNode(imageNamed: "GleeChange")
    let gleeChangeSad = SKSpriteNode(imageNamed: "GleeChangeSad")
    
    let gleeNewDefault = SKSpriteNode(imageNamed: "GleeNewDefault")
    let gleeChange1 = SKSpriteNode(imageNamed: "GleeChange1")
    let gleeChange2 = SKSpriteNode(imageNamed: "GleeChange2")
    let gleeChange3 = SKSpriteNode(imageNamed: "GleeChange3")
    let gleeFinal = SKSpriteNode(imageNamed: "GleeFinal")
    let gleeFinalSmile = SKSpriteNode(imageNamed: "GleeFinalSmile")
    
    
    
    // MARK: - Series of Actions
    /// object stumbling to the ground.
    func stumble (object: SKNode) {
        let moveAction = SKAction.move(to: CGPoint(x: 260, y: 240), duration: 0.3)
        let rotateAction = SKAction.rotate(toAngle: -0.52, duration: 0.1)
        let actionGroup = SKAction.group([moveAction, rotateAction])
        
        let moveAction2 = SKAction.move(to: CGPoint(x: 360, y: 160), duration: 0.5)
        let rotateAction2 = SKAction.rotate(toAngle: -1.91986, duration: 0.1)
        //        let changeGleeExpression = SKAction.run {
        //                  object.removeFromParent()
        //            self.addChild(self.gleeSad)
        //            }
        
        let actionGroup2 = SKAction.group([moveAction2,rotateAction2])
        
        let seq = SKAction.sequence([actionGroup,actionGroup2])
        object.run(seq)
        {
            if self.shouldGoToNextPhase {
                self.moveToNextPhase()
            }
        }
    }
    
    /// object rolling forward.
    func roll (object: SKNode) {
        let rollAction = SKAction.rotate(byAngle: -1.54, duration: 0.3)
        var rollActions = [SKAction]()
        
        for _ in 0...10{
            rollActions.append(rollAction)
        }
        
        let seq = SKAction.sequence(rollActions)
        object.run(seq) {
            if self.shouldGoToNextPhase {
                self.moveToNextPhase()
            }
        }
    }
    
    /// object shaking.
    func shake(object: SKNode) {
        let shake1 = SKAction.move(to: CGPoint(x: 200, y: 160), duration: 0.1)
        let shake2 = SKAction.move(to: CGPoint(x: 220, y: 160), duration: 0.1)
        let shake3 = SKAction.move(to: CGPoint(x: 200, y: 160), duration: 0.1)
        let shake4 = SKAction.move(to: CGPoint(x: 220, y: 160), duration: 0.1)
        
        let sequence = SKAction.sequence([shake1, shake2, shake3, shake4])
        
        object.run(sequence)
        {
            if self.shouldGoToNextPhase {
                self.moveToNextPhase()
            }
        }
    }
    
    /// object changing
    func shapeShift1 (object: SKNode) {
        let removeAction = SKAction.removeFromParent()
        let addChildAction = SKAction.run { [weak self] in
            guard let self = self else { return }
            self.addChild(self.gleeChange1)
        }
        let shapeAction = SKAction.run {
            // Change texture, scale, etc.
            object.position = CGPoint(x: 200, y: 160)
            object.setScale(0.5)
            //            object.size = self.gleeChange1.size
        }
        
        let shapeShiftAction = SKAction.sequence([removeAction, addChildAction, shapeAction])
        
        object.run(shapeShiftAction){
            if self.shouldGoToNextPhase {
                self.moveToNextPhase()
            }
        }
    }
    
    // MARK: - Gestures
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        for touch in touches {
            let location = touch.location(in: scene?.view)
            //            if location < (scene?.view?.frame.width ?? 0) / 2 {
            //
            //            }
            handleTap(at: location)
        }
    }
    
    
    
    func startPhase1() {
        let text = SKLabelNode(text: "Hello, I'm Glee the Triangle!\n I need you to help me roll. \n\n ( swipe to roll )").multilined()
        text.name = "text"
        text.position = CGPoint(x: 300, y: 500)
        addChild(text)
        
        glee.position = CGPoint(x: 200, y: 160)
        glee.setScale(0.5)
        addChild(glee)
                
    }
    
    func startPhase2() {
        let textNodeToRemove = childNode(withName: "text")
        textNodeToRemove?.removeFromParent()
        
        let text = SKLabelNode(text: "Oops! I stumble and do not roll. \n\n ( tap to next)").multilined()
        text.name = "text"
        
        text.position = CGPoint(x: 300, y: 500)
        addChild(text)
        
        glee.position = CGPoint(x: 360, y: 160)
        //        rightTapFunction()
        //        currentPhase = .phase3
    }
    
    func startPhase3() {
        let textNodeToRemove = childNode(withName: "text")
        textNodeToRemove?.removeFromParent()
        
        let textLearn = SKLabelNode(text: "Lesson Learned: \n Swipe gesture makes triangle stumble.").multilined()
        textLearn.name = "text"
        
        scene?.addChild(textLearn)
        textLearn.position = CGPoint(x: 300, y: 720)
        
        let text = SKLabelNode(text: "It's okay! \n Let's find another way ahead. \n\n ( tap to next )").multilined()
        text.name = "text"
        
        scene?.addChild(text)
        text.position = CGPoint(x: 300, y: 500)
        let stand = SKAction.rotate(toAngle: 0, duration: 0.2)
        glee.run(stand)
        glee.name = "glee"
        
    }
    
    func startPhase4(){
        let textNodeToRemove = childNode(withName: "text")
        textNodeToRemove?.removeFromParent()
        
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "glee")?.removeFromParent()
        
        
        let textLearn = SKLabelNode(text: "Lesson Learned: \n Swipe gesture makes triangle stumble.").multilined()
        textLearn.name = "text"
        
        scene?.addChild(textLearn)
        textLearn.position = CGPoint(x: 300, y: 720)
        
        let text = SKLabelNode(text: "Can I roll with this? \n\n ( swipe to roll )").multilined()
        text.name = "text"
        
        scene?.addChild(text)
        text.position = CGPoint(x: 300, y: 500)
        
        squareHappy.position = CGPoint(x: 200, y: 226)
        squareHappy.setScale(0.4)
        addChild(squareHappy)
        squareHappy.name = "glee"
        
    }
    
    func startPhase5(){
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "glee")?.removeFromParent()
        
        
        let textLearn = SKLabelNode(text: "Lesson Learned: \n Swipe gesture makes triangle stumble.").multilined()
        textLearn.name = "text"
        
        scene?.addChild(textLearn)
        textLearn.position = CGPoint(x: 300, y: 720)
        
        let text = SKLabelNode(text: "Uh-oh, I'm not moving at all. \n\n ( tap to next )").multilined()
        text.name = "text"
        
        scene?.addChild(text)
        text.position = CGPoint(x: 300, y: 500)
        
        squareSad.position = CGPoint(x: 200, y: 226)
        squareSad.setScale(0.4)
        addChild(squareSad)
        squareSad.name = "glee"
        
    }
    
    func startPhase6(){
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "glee")?.removeFromParent()
        
        let textLearn = SKLabelNode(text: "Lesson Learned: \n Swipe gesture makes triangle stumble. \n I can't roll with angles.").multilined()
        textLearn.name = "text"
        
        scene?.addChild(textLearn)
        textLearn.position = CGPoint(x: 300, y: 720)
        
        let text = SKLabelNode(text: "It's okay! \n At least we've learned something. \n\n ( tap to next )").multilined()
        text.name = "text"
        
        scene?.addChild(text)
        text.position = CGPoint(x: 300, y: 500)
        
        glee.position = CGPoint(x: 200, y: 160)
        glee.setScale(0.5)
        addChild(glee)
        glee.name = "glee"
        
    }
    
    func startPhase7(){
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "glee")?.removeFromParent()
        
        let textLearn = SKLabelNode(text: "Lesson Learned: \n Swipe gesture makes triangle stumble. \n I can't roll with angles.").multilined()
        textLearn.name = "text"
        
        scene?.addChild(textLearn)
        textLearn.position = CGPoint(x: 300, y: 720)
        
        let text = SKLabelNode(text: "Can I roll with this? \n\n ( swipe to roll )").multilined()
        text.name = "text"
        
        scene?.addChild(text)
        text.position = CGPoint(x: 300, y: 500)
        
        circleSmile.position = CGPoint(x: 200, y: 226)
        circleSmile.setScale(0.4)
        addChild(circleSmile)
        circleSmile.name = "glee"
        
    }
    
    func startPhase8(){
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "glee")?.removeFromParent()
        
        let textLearn = SKLabelNode(text: "Lesson Learned: \n Swipe gesture makes triangle stumble. \n I can't roll with angles.").multilined()
        textLearn.name = "text"
        
        scene?.addChild(textLearn)
        textLearn.position = CGPoint(x: 300, y: 720)
        
        let text = SKLabelNode(text: "YAY! I can finally roll! \n It's not perfect, but okay. \n \n Now, let's roll til we find a green flag. \n\n ( swipe to roll )").multilined()
        text.name = "text"
        
        scene?.addChild(text)
        text.position = CGPoint(x: 300, y: 500)
        
        circleHappy.position = CGPoint(x: 200, y: 226)
        circleHappy.setScale(0.4)
        addChild(circleHappy)
        circleHappy.name = "glee"
        
    }
    
    func startPhase9(){
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "glee")?.removeFromParent()
        
        let textLearn = SKLabelNode(text: "Lesson Learned: \n Swipe gesture makes triangle stumble. \n I can't roll with angles.").multilined()
        textLearn.name = "text"
        
        scene?.addChild(textLearn)
        textLearn.position = CGPoint(x: 300, y: 720)
        
        let text = SKLabelNode(text: "Whoa! \n\n ( keep rolling )" ).multilined()
        text.name = "text"
        
        scene?.addChild(text)
        text.position = CGPoint(x: 300, y: 500)
        
        circleO.position = CGPoint(x: 200, y: 226)
        circleO.setScale(0.4)
        addChild(circleO)
        circleO.name = "glee"
        
    }
    
    func startPhase10(){
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "glee")?.removeFromParent()
        
        let textLearn = SKLabelNode(text: "Lesson Learned: \n Swipe gesture makes triangle stumble. \n I can't roll with angles.").multilined()
        textLearn.name = "text"
        
        scene?.addChild(textLearn)
        textLearn.position = CGPoint(x: 300, y: 720)
        
        let text = SKLabelNode(text: "Whoops! Now that's unexpected. \n\n ( tap to next )").multilined()
        text.name = "text"
        
        scene?.addChild(text)
        text.position = CGPoint(x: 300, y: 500)
        
        circle.position = CGPoint(x: 20, y: 226)
        circle.setScale(0.4)
        addChild(circle)
        circle.name = "glee"
        
        gleeNewDefault.position = CGPoint(x: 136, y: 156)
        gleeNewDefault.setScale(0.4)
        addChild(gleeNewDefault)
        gleeNewDefault.name = "gleeNew"
        
        greenFlag.position = CGPoint(x: 400, y: 186)
        greenFlag.setScale(0.3)
        addChild(greenFlag)
        greenFlag.name = "flag"
        
    }
    
    func startPhase11(){
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "glee")?.removeFromParent()
        
        let textLearn = SKLabelNode(text: "Lesson Learned: \n Swipe gesture makes triangle stumble. \n I can't roll with angles. \n I can change my form.").multilined()
        textLearn.name = "text"
        
        scene?.addChild(textLearn)
        textLearn.position = CGPoint(x: 300, y: 700)
        
        let text = SKLabelNode(text: "Hmmm.. from what we've learned, \n what else could we possibly do? \n\n ( try other swipe gesture )").multilined()
        text.name = "text"
        
        scene?.addChild(text)
        text.position = CGPoint(x: 300, y: 500)
        
        greenFlag.position = CGPoint(x: 400, y: 186)
        gleeNewDefault.position = CGPoint(x: 136, y: 156)
        
    }
    
    func startPhase12(){
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "gleeNew")?.removeFromParent()
        
        let textLearn = SKLabelNode(text: "Lesson Learned: \n Swipe gesture makes triangle stumble. \n I can't roll with angles. \n I can change my form.").multilined()
        textLearn.name = "text"
        
        scene?.addChild(textLearn)
        textLearn.position = CGPoint(x: 300, y: 700)
        
        let text = SKLabelNode(text: "Whoa!").multilined()
        text.name = "text"
        
        scene?.addChild(text)
        text.position = CGPoint(x: 300, y: 500)
        
        greenFlag.position = CGPoint(x: 400, y: 186)
        
        gleeChange3.position = CGPoint(x: 136, y: 166)
        gleeChange3.setScale(0.5)
        addChild(gleeChange3)
        gleeChange3.name = "gleeNew"
        
    }
    
    func startPhase13(){
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "gleeNew")?.removeFromParent()
        
        let textLearn = SKLabelNode(text: "Lesson Learned: \n Swipe gesture makes triangle stumble. \n I can't roll with angles. \n I can change my form.").multilined()
        textLearn.name = "text"
        
        scene?.addChild(textLearn)
        textLearn.position = CGPoint(x: 300, y: 700)
        
        let text = SKLabelNode(text: "Impressive! \n Now I'm' Glee the Circle! \n \n So, let's roll to the green flag. \n\n ( swipe to roll )").multilined()
        text.name = "text"
        
        scene?.addChild(text)
        text.position = CGPoint(x: 300, y: 500)
        
        greenFlag.position = CGPoint(x: 400, y: 186)
        
        gleeFinal.position = CGPoint(x: 136, y: 166)
        gleeFinal.setScale(0.5)
        addChild(gleeFinal)
        gleeFinal.name = "gleeNew"
        
        
    }
    
    func startPhase14(){
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "text")?.removeFromParent()
        childNode(withName: "gleeNew")?.removeFromParent()
        
        let textLearn = SKLabelNode(text: "YAY! WE DID IT!").multilined()
        
        scene?.addChild(textLearn)
        textLearn.position = CGPoint(x: 300, y: 700)
        
        let text = SKLabelNode(text: "Thank you for being \n the part of my journey to roll! \n \n Now, it's your turn to keep \n rolling in life til you meet your own goal :) \n \n Keep rolling!").multilined()
        
        scene?.addChild(text)
        text.position = CGPoint(x: 300, y: 500)
        
        gleeFinalSmile.position = CGPoint(x: 292, y: 166)
        gleeFinalSmile.setScale(0.5)
        addChild(gleeFinalSmile)
        
    }
    
    // "Tap Gesture" recognizer
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        // Called when touches end
        for touch in touches {
            let location = touch.location(in: self)
            // Handle tap at location
            handleTap(at: location)
        }
    }
    
    func handleTap(at position: CGPoint) {
        if position.x < 300 {
            leftTapFunction()
        } else {
            rightTapFunction()
        }
    }
    
    func leftTapFunction() {
        print("left tap")
        print(currentPhase)
        //        let previousPhase = currentPhase.rawValue - 1
        //        currentPhase = StoryPhase(rawValue: previousPhase) ?? .phase0
    }
    
    func rightTapFunction() {
        print("right tap")
        print(currentPhase)
        switch currentPhase {
        case .phase0:
            break
        case .phase1:
            break
        case .phase2:
            shouldGoToNextPhase = true
            moveToNextPhase()
            break
        case .phase3:
            shouldGoToNextPhase = true
            moveToNextPhase()
            break
        case .phase4:
            break
        case .phase5:
            shouldGoToNextPhase = true
            moveToNextPhase()
            break
        case .phase6:
            shouldGoToNextPhase = true
            moveToNextPhase()
            break
        case .phase7:
            break
        case .phase8:
            break
        case .phase9:
            break
        case .phase10:
            shouldGoToNextPhase = true
            moveToNextPhase()
            break
        case .phase11:
            shouldGoToNextPhase = true
            break
        case .phase12:
            shouldGoToNextPhase = true
            break
        case .phase13:
            break
        case .phase14:
            break
        }
        
    }
    
    override func didMove(to view: SKView) {
        
        self.backgroundColor = UIColor.black
        
        line.position = CGPoint(x: 200, y: 100)
        line.setScale(0.5)
        addChild(line)
        
        self.isUserInteractionEnabled = true
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        view.addGestureRecognizer(tapGesture)
        
        // "Swipe" gesture recognizer
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
        swipeRight.direction = .right
        view.addGestureRecognizer(swipeRight)
        
        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
        swipeLeft.direction = .left
        view.addGestureRecognizer(swipeLeft)
        
        let swipeUp = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
        swipeUp.direction = .up
        view.addGestureRecognizer(swipeUp)
        
        let swipeDown = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
        swipeDown.direction = .down
        view.addGestureRecognizer(swipeDown)
        
        // MARK: - Controlling first phase
        switch currentPhase {
            
        case .phase1:
            startPhase1()
            break
        case .phase2:
            startPhase2()
            break
        case .phase3:
            startPhase3()
            break
        case .phase4:
            startPhase4()
            break
        case .phase5:
            startPhase5()
            break
        case .phase6:
            startPhase6()
            break
        case .phase7:
            startPhase7()
            break
        case .phase8:
            startPhase8()
            break
        case .phase9:
            startPhase9()
            break
        case .phase10:
            startPhase10()
            break
        case .phase11:
            startPhase11()
            break
        case .phase12:
            startPhase12()
        case .phase13:
            startPhase13()
            break
        case .phase14:
            startPhase14()
            break
        default:
            break
        }
    }
    
    
    // MARK: - Handle Swipe
    @objc func handleSwipe(_ sender: UISwipeGestureRecognizer) {
        switch sender.direction {
        case .right:
            /// Perform action for right swipe
            switch currentPhase {
            case .phase0:
                print(" - ")
            case .phase1:
                shouldGoToNextPhase = true
                stumble(object: glee)
            case .phase2:
                print(" - ")
            case .phase3:
                print(" - ")
            case .phase4:
                shouldGoToNextPhase = true
                moveToNextPhase()
                print(" - ")
            case .phase5:
                print(" - ")
            case .phase6:
                shouldGoToNextPhase = true
                moveToNextPhase()
                print(" - ")
            case .phase7:
                shouldGoToNextPhase = true
                roll(object: circleHappy)
                moveToNextPhase()
            case .phase8:
                shouldGoToNextPhase = true
                roll(object: circleO)
                moveToNextPhase()
            case .phase9:
                shouldGoToNextPhase = true
                roll(object: circleO)
                moveToNextPhase()
            case .phase10:
                print(" - ")
            case .phase11:
                print(" - ")
            case .phase12:
                print(" - ")
            case .phase13:
                shouldGoToNextPhase = true
                roll(object: gleeFinal)
                moveToNextPhase()
            case .phase14:
                print(" - ")
            }
            
            print("Swiped Right")
        case .left:
            /// Perform action for left swipe
            print("Swiped Left")
        case .up:
            /// Perform action for up swipe
            switch currentPhase {
            case .phase0:
                print(" - ")
            case .phase1:
                print(" - ")
            case .phase2:
                print(" - ")
            case .phase3:
                print(" - ")
            case .phase4:
                print(" - ")
            case .phase5:
                print(" - ")
            case .phase6:
                print(" - ")
            case .phase7:
                print(" - ")
            case .phase8:
                print(" - ")
            case .phase9:
                print(" - ")
            case .phase10:
                print(" - ")
            case .phase11:
                print(" - ")
            case .phase12:
                shouldGoToNextPhase = true
                shapeShift1 (object: gleeFinal)
                moveToNextPhase()
            case .phase13:
                print(" - ")
            case .phase14:
                print(" - ")
            }
            print("Swiped Up")
        case .down:
            /// Perform action for down swipe
            switch currentPhase {
            case .phase0:
                print(" - ")
            case .phase1:
                print(" - ")
            case .phase2:
                print(" - ")
            case .phase3:
                print(" - ")
            case .phase4:
                print(" - ")
            case .phase5:
                print(" - ")
            case .phase6:
                print(" - ")
            case .phase7:
                print(" - ")
            case .phase8:
                print(" - ")
            case .phase9:
                print(" - ")
            case .phase10:
                print(" - ")
            case .phase11:
                shouldGoToNextPhase = true
                shapeShift1(object: gleeNewDefault)
                moveToNextPhase()
            case .phase12:
                print(" - ")
            case .phase13:
                print(" - ")
            case .phase14:
                print(" - ")
            }
            print("Swiped Down")
        default:
            break
        }
    }
    
    // MARK: - Should Go To Next Phase
    func moveToNextPhase() {
        if shouldGoToNextPhase {
            switch currentPhase {
            case .phase0:
                startPhase1()
                break
            case .phase1:
                startPhase2()
                break
            case .phase2:
                startPhase3()
                break
            case .phase3:
                startPhase4()
                break
            case .phase4:
                startPhase5()
                break
            case .phase5:
                startPhase6()
                break
            case .phase6:
                startPhase7()
                break
            case .phase7:
                startPhase8()
                break
            case .phase8:
                startPhase9()
                break
            case .phase9:
                startPhase10()
                break
            case .phase10:
                startPhase11()
                break
            case .phase11:
                startPhase12()
                break
            case .phase12:
                startPhase13()
                break
            case .phase13:
                startPhase14()
                break
            case .phase14:
                break
            }
        }
        let nextPhase = currentPhase.rawValue + 1
        currentPhase = StoryPhase(rawValue: nextPhase) ?? .phase0
        shouldGoToNextPhase = false
    }
    
    // MARK: - Handle Tap
    @objc func handleTap(_ sender: UITapGestureRecognizer) {
        if isPhase1Complete {
            startPhase2()
        }
    }
}

extension SKLabelNode {
    func multilined() -> SKLabelNode {
        let substrings: [String] = self.text!.components(separatedBy: "\n")
        return substrings.enumerated().reduce(SKLabelNode()) {
            let label = SKLabelNode(fontNamed: self.fontName)
            label.text = $1.element
            label.fontColor = self.fontColor
            label.fontSize = self.fontSize
            label.position = self.position
            label.horizontalAlignmentMode = self.horizontalAlignmentMode
            label.verticalAlignmentMode = self.verticalAlignmentMode
            let y = CGFloat($1.offset - substrings.count / 2) * self.fontSize
            label.position = CGPoint(x: 0, y: -y)
            $0.addChild(label)
            return $0
        }
    }
}
