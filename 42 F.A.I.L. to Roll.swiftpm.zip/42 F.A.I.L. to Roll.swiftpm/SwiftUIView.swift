//
//  SwiftUIView.swift
//  42 F.A.I.L. to Roll
//
//  Created by Antonia Angelia Widjaja on 24/02/24.
//

import SwiftUI
import SpriteKit

struct SwiftUIView: View {
// Initialize and host the Game Scene
    var scene: SKScene {
        let scene = GameScene()
        scene.size = CGSize(width: 600, height: 800)
        scene.scaleMode = .aspectFit
        let cameraNode = SKCameraNode()
            
        cameraNode.position = CGPoint(x: scene.size.width / 2, y: scene.size.height / 2)
            
        scene.addChild(cameraNode)
        scene.camera = cameraNode
        return scene
    }
    
    var body: some View {
    //Show the game scene in SwiftUI view
        SpriteView(scene: self.scene)
            .ignoresSafeArea()
    }
}


#Preview {
    SwiftUIView()
}
